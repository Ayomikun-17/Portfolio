// ==============================
// TASKFLOW APP
// ==============================

// Get elements from HTML
const taskForm = document.getElementById("taskForm");
const taskList = document.getElementById("taskList");


// ==============================
// LOAD SAVED TASKS
// ==============================

// Get tasks from localStorage
let tasks = JSON.parse(localStorage.getItem("tasks")) || [];


// ==============================
// ADD TASK
// ==============================

taskForm.addEventListener("submit", function(event) {

    // Stop page from refreshing
    event.preventDefault();

    // Get information from the form
    const title = document.getElementById("taskTitle").value.trim();
    const priority = document.getElementById("taskPriority").value;
    const dueDate = document.getElementById("taskDueDate").value;

    // Create task
    const task = {
        id: Date.now(),
        title: title,
        priority: priority,
        dueDate: dueDate,
        completed: false
    };

    // Add task to array
    tasks.push(task);

    // Save tasks
    saveTasks();

    // Display tasks
    displayTasks();

    // Clear form
    taskForm.reset();
});


// ==============================
// SAVE TASKS
// ==============================

function saveTasks() {

    localStorage.setItem(
        "tasks",
        JSON.stringify(tasks)
    );

}


// ==============================
// DISPLAY TASKS
// ==============================

function displayTasks() {

    taskList.innerHTML = "";

    // If there are no tasks
    if (tasks.length === 0) {

        taskList.innerHTML = `
            <p id="emptyMessage">
                No tasks yet. Add your first task!
            </p>
        `;

        return;
    }


    // Display each task
    tasks.forEach(function(task) {

        const taskCard = document.createElement("div");

        taskCard.className = "task-card";

        taskCard.innerHTML = `
            
            <div class="task-info">

                <h3>${task.title}</h3>

                <p>
                    Priority: ${task.priority}
                </p>

                <p>
                    Due: ${task.dueDate || "No due date"}
                </p>

            </div>

        `;

        taskList.appendChild(taskCard);
    });
}


// ==============================
// SHOW SAVED TASKS
// ==============================

// Run when the page opens
displayTasks();